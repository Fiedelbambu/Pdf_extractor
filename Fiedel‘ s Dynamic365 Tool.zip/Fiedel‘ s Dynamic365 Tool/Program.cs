﻿using System;
using System.Threading.Tasks;
using FiedelsDynamic365Tool.Interfaces;
using FiedelsDynamic365Tool.Models;
using FiedelsDynamic365Tool.Service;
using Microsoft.Extensions.DependencyInjection;

namespace FiedelsDynamic365Tool
{
    class Program
    {
        static async Task Main(string[] args)
        {           

            var serviceProvider = new ServiceCollection()
                .AddSingleton(new ConfigReader("konfig/einrichten.txt"))
                .AddSingleton<ILoggerService, LoggerService>()
                .AddSingleton<IFileReader, FileReader>()
                .AddSingleton<IPdfExtractorService, PdfExtractorService>()
                .AddSingleton<IDataverseService>(provider =>
                {
                    var logger = provider.GetRequiredService<ILoggerService>();
                    var pdfExtractor = provider.GetRequiredService<IPdfExtractorService>();
                    var configReader = provider.GetRequiredService<ConfigReader>();

                    return new DataverseService(logger, pdfExtractor, configReader);
                })
              .AddSingleton<IFacadeService>(provider =>
              {
                  var logger = provider.GetService<ILoggerService>();
                  var pdfExtractor = provider.GetService<IPdfExtractorService>();
                  var dataverseService = provider.GetService<IDataverseService>();
                  //kein NullWert Abfrage
                  if (logger == null || pdfExtractor == null || dataverseService == null)
                  {
                      var missingServices = new List<string>();
                      if (logger == null) missingServices.Add("logger");
                      if (pdfExtractor == null) missingServices.Add("pdfDataExtractor");
                      if (dataverseService == null) missingServices.Add("dataverseService");

                      throw new InvalidOperationException($"Die folgenden Dienste dürfen nicht null sein: {string.Join(", ", missingServices)}.");
                  }

                  return new FacadeService(pdfExtractor, dataverseService, provider.GetRequiredService<IFileReader>(), logger);
              })
                .BuildServiceProvider();

            var facadeService = serviceProvider.GetService<IFacadeService>();


            if (facadeService == null)
            {
                Console.WriteLine("Failed to initialize the FacadeService.");
                return;
            }

            try
            {
                await facadeService.ProcessPdfAndCreateRecordsAsync();
                Console.WriteLine("Processing completed successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
