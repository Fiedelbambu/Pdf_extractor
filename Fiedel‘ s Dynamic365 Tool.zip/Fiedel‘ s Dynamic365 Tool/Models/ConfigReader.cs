﻿using System;
using System.IO;

namespace FiedelsDynamic365Tool.Models
{
    public class ConfigReader
    {
        public string? DefaultPdfPath { get; private set; }
        public string? TempFolder { get; private set; }
        public string? FailedFolder { get; private set; }
        public string? ArchiveFolder { get; private set; }
        public string? ApplicationLog { get; private set; }
        public string? EncryptionData { get; private set; }

        private readonly string[] defaultPaths =
        {
            @"C:\InProgress\",
            @"C:\Temp",
            @"C:\Failed",
            @"C:\Archive"
        };

        public ConfigReader(string configFilePath) => LoadPathsFromConfig(configFilePath); //Lambda ausdruck

        private void LoadPathsFromConfig(string configFilePath)
        {
            if (File.Exists(configFilePath))
            {
                foreach (var line in File.ReadAllLines(configFilePath))
                {
                    var split = line.Split('=');
                    if (split.Length == 2)
                    {
                        var key = split[0].Trim().ToLower();
                        var value = split[1].Trim();

                        switch (key)
                        {
                            case "defaultpdfpath":
                                DefaultPdfPath = value;
                                break;
                            case "tempfolder":
                                TempFolder = value;
                                break;
                            case "failedfolder":
                                FailedFolder = value;
                                break;
                            case "archivefolder":
                                ArchiveFolder = value;
                                break;
                            case "applicationlog":
                                ApplicationLog = value;
                                break;
                            case "encryptedconnectionstring":
                                EncryptionData = value;
                                break;
                        }
                    }
                }
            }

            SetDefaultPathsIfNeeded();
        }

        private void SetDefaultPathsIfNeeded()
        {
            DefaultPdfPath ??= defaultPaths[0];
            TempFolder ??= defaultPaths[1];
            FailedFolder ??= defaultPaths[2];
            ArchiveFolder ??= defaultPaths[3];

            DefaultPdfPath = Directory.Exists(DefaultPdfPath) ? DefaultPdfPath : defaultPaths[0];
            TempFolder = Directory.Exists(TempFolder) ? TempFolder : defaultPaths[1];
            FailedFolder = Directory.Exists(FailedFolder) ? FailedFolder : defaultPaths[2];
            ArchiveFolder = Directory.Exists(ArchiveFolder) ? ArchiveFolder : defaultPaths[3];
        }
    }
}
