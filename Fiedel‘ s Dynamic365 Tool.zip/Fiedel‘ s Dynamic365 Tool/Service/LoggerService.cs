﻿using System;
using System.IO;
using FiedelsDynamic365Tool.Interfaces;
using FiedelsDynamic365Tool.Models;

namespace FiedelsDynamic365Tool.Service
{
    public class LoggerService : ILoggerService
    {
        private readonly string _logFilePath;

        public LoggerService(ConfigReader configReader)
        {            
            string binPath = AppDomain.CurrentDomain.BaseDirectory;
            _logFilePath = configReader.ApplicationLog ?? throw new ArgumentNullException(nameof(configReader.ApplicationLog));
        }

        public void LogInfo(string message)
        {
            Log("INFO", message);
        }

        public void LogWarn(string message)
        {
            Log("WARNING", message);
        }

        public void LogError(string message, Exception? ex = null)
        {
            string fullMessage = ex == null ? message : $"{message}: {ex.Message}\n{ex.StackTrace}";
            Log("ERROR", fullMessage);
        }

        private void Log(string level, string message)
        {
            string logMessage = $"{DateTime.Now:dd-MM-yyyy HH:mm} [{level}] {message}";
            LogToFile(logMessage);
        }

        private void LogToFile(string logMessage)
        {            
            string directoryPath = Path.GetDirectoryName(_logFilePath);
            
            if (!string.IsNullOrEmpty(directoryPath) && !Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
            
            using (StreamWriter writer = new StreamWriter(_logFilePath, true))
            {
                writer.WriteLine(logMessage);
            }
        }
    }
}
